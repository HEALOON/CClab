let cow1; // global cow instance
let cowIMG;

let cows = [];
let numCows = 20;

function preload(){
    cowIMG = loadImage("assets/cow-poster.png");
}

function setup() {
    let cnv = createCanvas(windowWidth, windowHeight);
    cnv.parent("canvas-parent");

    // cow1 = new Cow(300, 200, cowIMG); // instantiate cow object
    // console.log(cow1)

    // MAKE INITIAL COWS and put the into the cows array
    for(let i = 0; i < numCows; i++){
        let ranX = random(width);
        let ranY = random(0, height/2)
        let oneCow = new Cow(ranX, ranY, cowIMG); 
        cows.push(oneCow)
    }
    console.log(cows)
}

function draw() {
    background(220, 50, 120);
    // cow1.display(); // display the cow
    // cow1.update(); // update the cow

    // DO STUFF FOR EACH COW --> loop over the cows array
    for(let i = 0; i < cows.length; i++){
        cows[i].display();
        cows[i].update();
    }


    line(0, height/2, width, height/2);
    line(width/2, height/2, width/2, height);
   
}

class Cow{
    constructor(startX, startY, cowimg){
        this.x = startX;
        this.y = startY;
        this.photo = cowimg;
        this.scaleFactor = random(0.4, 0.5);

        this.xSpeed = 1;
        this.ySpeed = 1;
    }
    update(){
        
    }
    display(){
        push();
        translate(this.x, this.y);
        scale(this.scaleFactor);

        // rect(0, 0, 50, 50);

        // we reposition the img to 
        // better fit this object's origin point (this.x, this.y)
        let imgW = this.photo.width;
        let imgH = this.photo.height;
        //       the img      x        y 
        image(this.photo, -imgW/2, -imgH+90);

        fill("blue");
        circle(0,0,5);

        pop();
    }
}